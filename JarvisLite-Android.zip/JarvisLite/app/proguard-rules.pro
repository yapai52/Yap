# Bu dosya release derlemede minify aktif edilirse kullanılır.
# Şu an minifyEnabled false, bu yüzden boş bırakılabilir.
