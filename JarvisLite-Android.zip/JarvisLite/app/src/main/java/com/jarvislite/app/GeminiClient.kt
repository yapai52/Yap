package com.jarvislite.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Google Gemini API ile konuşan istemci.
 *
 * İki şey yapar:
 * 1) askQuestion: serbest metin sorularına cevap alır (genel sohbet/soru-cevap)
 * 2) generateImage: metinden görsel üretir, base64 olarak gelen veriyi Bitmap'e çevirir
 *
 * NOT: Bu sınıf ağ çağrılarını senkron (bloklayan) şekilde yapar; bu yüzden
 * her zaman bir arka plan thread'inden (örn. Thread{...} veya Executor) çağrılmalı,
 * ana thread'den çağrılırsa uygulama donar/çöker.
 */
class GeminiClient(private val context: Context) {

    companion object {
        private const val TAG = "GeminiClient"
        private const val TEXT_MODEL = "gemini-2.5-flash"
        private const val IMAGE_MODEL = "gemini-2.5-flash-image"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun apiKey(): String {
        val key = context.getString(R.string.gemini_api_key)
        return key.trim()
    }

    private fun hasValidKey(): Boolean {
        val key = apiKey()
        return key.isNotBlank() && key != "BURAYA_KENDI_API_ANAHTARINI_YAPISTIR"
    }

    /**
     * Serbest bir soruyu Gemini'ye gönderir, metin cevabını döner.
     * Hata olursa kullanıcıya gösterilebilecek açıklayıcı bir metin döner (exception fırlatmaz).
     */
    fun askQuestion(question: String): String {
        if (!hasValidKey()) {
            return "Gemini API anahtarı tanımlanmamış. Lütfen strings.xml dosyasındaki gemini_api_key alanına kendi anahtarınızı ekleyin."
        }

        return try {
            val requestBody = JSONObject().apply {
                put("contents", JSONArray().put(
                    JSONObject().apply {
                        put("parts", JSONArray().put(
                            JSONObject().apply {
                                put("text", question)
                            }
                        ))
                    }
                ))
                // Türkçe ve kısa/sesli okunabilir cevaplar için sistem talimatı
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(
                        JSONObject().apply {
                            put("text", "Sen Vea adında, Türkçe konuşan sesli bir asistansın. " +
                                "Cevaplarını kısa, doğal ve sesli okunmaya uygun ver. " +
                                "Madde işareti veya markdown kullanma, düz konuşma dili kullan.")
                        }
                    ))
                })
            }

            val url = "$BASE_URL/$TEXT_MODEL:generateContent?key=${apiKey()}"
            val response = postJson(url, requestBody)
            extractTextFromResponse(response)
        } catch (e: Exception) {
            Log.e(TAG, "askQuestion hatası", e)
            "Bir sorun oluştu, internet bağlantınızı kontrol edin."
        }
    }

    /**
     * Metinden görsel üretir. Başarılıysa Bitmap, başarısızsa null döner.
     */
    fun generateImage(prompt: String): Bitmap? {
        if (!hasValidKey()) return null

        return try {
            val requestBody = JSONObject().apply {
                put("contents", JSONArray().put(
                    JSONObject().apply {
                        put("parts", JSONArray().put(
                            JSONObject().apply {
                                put("text", prompt)
                            }
                        ))
                    }
                ))
            }

            val url = "$BASE_URL/$IMAGE_MODEL:generateContent?key=${apiKey()}"
            val response = postJson(url, requestBody)
            extractImageFromResponse(response)
        } catch (e: Exception) {
            Log.e(TAG, "generateImage hatası", e)
            null
        }
    }

    // ---------- Ağ yardımcıları ----------

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val mediaType = "application/json".toMediaType()
        val requestBody = body.toString().toRequestBody(mediaType)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                Log.e(TAG, "API hatası: ${response.code} - $responseText")
                throw IOException("API isteği başarısız: ${response.code}")
            }
            return JSONObject(responseText)
        }
    }

    private fun extractTextFromResponse(response: JSONObject): String {
        return try {
            val candidates = response.getJSONArray("candidates")
            val content = candidates.getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")
            parts.getJSONObject(0).getString("text").trim()
        } catch (e: Exception) {
            Log.e(TAG, "Cevap ayrıştırılamadı: $response", e)
            "Cevabı anlayamadım, tekrar dener misiniz?"
        }
    }

    private fun extractImageFromResponse(response: JSONObject): Bitmap? {
        return try {
            val candidates = response.getJSONArray("candidates")
            val content = candidates.getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("inlineData")) {
                    val base64Data = part.getJSONObject("inlineData").getString("data")
                    val imageBytes = Base64.decode(base64Data, Base64.DEFAULT)
                    return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                }
            }
            null
        } catch (e: Exception) {
            Log.e(TAG, "Görsel ayrıştırılamadı: $response", e)
            null
        }
    }
}
