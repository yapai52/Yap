package com.jarvislite.app

import android.app.admin.DeviceAdminReceiver

/**
 * "Telefonu kilitle" komutunun çalışması için Android'in istediği boş bir alıcı.
 * Kullanıcı, ayarlarda bu uygulamaya "Cihaz Yöneticisi" yetkisi verdiğinde
 * DevicePolicyManager.lockNow() çağrısı geçerli olur.
 */
class VeaDeviceAdminReceiver : DeviceAdminReceiver()
