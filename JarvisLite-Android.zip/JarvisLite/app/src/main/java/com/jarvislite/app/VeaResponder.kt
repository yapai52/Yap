package com.jarvislite.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Uyandırma kelimesi duyulduktan sonraki akışı yönetir:
 * 1) Sesli olarak "Buyrun, Vea hizmetinizde" der (TextToSpeech)
 * 2) Kullanıcının komutunu/sorusunu dinler
 * 3) Komutu işler: uygulama açma, basit soru-cevap, veya kilit açma isteği
 */
class VeaResponder(private val context: Context) {

    private var tts: TextToSpeech? = null
    private val commandHandler = AppCommandHandler(context)
    private val geminiClient = GeminiClient(context)

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
            }
        }
    }

    /**
     * "Buyrun, vea hizmetinizde" der, konuşma bitince komutu dinlemeye başlar.
     * onComplete: komut işlendikten sonra çağrılır (servis tekrar uyandırma kelimesi dinlemeye döner).
     */
    fun respondAndListenForCommand(onComplete: () -> Unit) {
        speak("Buyrun, Vea hizmetinizde") {
            listenForCommand(onComplete)
        }
    }

    private fun listenForCommand(onComplete: () -> Unit) {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                recognizer.destroy()
                processCommand(text, onComplete)
            }

            override fun onError(error: Int) {
                recognizer.destroy()
                speak("Anlayamadım, tekrar deneyebilir misiniz") { onComplete() }
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        }
        recognizer.startListening(intent)
    }

    /**
     * Komutu kategori kategori değerlendirir:
     * - "kilidi aç" -> biyometri isteğini tetikleyen Activity'yi açar
     * - "kapat" / "kilitle" -> ekranı kilitler
     * - saat/tarih sorusu -> doğrudan cevaplar
     * - aksi halde -> uygulama açmayı dener
     */
    private fun processCommand(rawText: String, onComplete: () -> Unit) {
        val text = rawText.lowercase().trim()

        when {
            text.isBlank() -> {
                speak("Bir şey duymadım") { onComplete() }
            }

            text.contains("kilidi aç") || text.contains("kilit aç") -> {
                speak("Kilidi açmak için parmak izinizi veya yüzünüzü onaylayın") {
                    val intent = Intent(context, MainActivity::class.java).apply {
                        action = MainActivity.ACTION_UNLOCK_REQUEST
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    onComplete()
                }
            }

            text.contains("kilitle") || text.contains("ekranı kapat") -> {
                speak("Telefonu kilitliyorum") {
                    val intent = Intent(context, MainActivity::class.java).apply {
                        action = MainActivity.ACTION_LOCK_SCREEN
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    onComplete()
                }
            }

            text.contains("saat kaç") -> {
                val time = SimpleDateFormat("HH:mm", Locale("tr")).format(Date())
                speak("Saat $time") { onComplete() }
            }

            text.contains("bugün ayın kaçı") || text.contains("tarih ne") -> {
                val date = SimpleDateFormat("d MMMM yyyy", Locale("tr")).format(Date())
                speak(date) { onComplete() }
            }

            // "çiz", "resim yap", "görsel oluştur" gibi ifadeler -> Gemini'den görsel üret
            text.contains("çiz") || text.contains("resim yap") || text.contains("resim oluştur")
                || text.contains("görsel oluştur") || text.contains("görsel yap") -> {
                speak("Hemen çiziyorum, biraz bekleyin") {
                    generateAndSaveImage(text, onComplete)
                }
            }

            // Önceden tanımlı kalıplara uymayan her şey -> önce uygulama açma dene,
            // bulamazsa Gemini'ye genel bir soru olarak sor
            else -> {
                val match = commandHandler.findBestMatch(text)
                if (match != null) {
                    val launched = commandHandler.launchApp(match)
                    val message = if (launched) "${match.label} açılıyor" else "${match.label} açamadım"
                    speak(message) { onComplete() }
                } else {
                    askGeminiAndSpeak(text, onComplete)
                }
            }
        }
    }

    /** Soruyu Gemini'ye gönderir (arka plan thread'inde), cevabı sesli okur. */
    private fun askGeminiAndSpeak(question: String, onComplete: () -> Unit) {
        Thread {
            val answer = geminiClient.askQuestion(question)
            speak(answer) { onComplete() }
        }.start()
    }

    /** Gemini'den görsel üretir, telefonun Pictures klasörüne kaydeder, sonucu sesli bildirir. */
    private fun generateAndSaveImage(prompt: String, onComplete: () -> Unit) {
        Thread {
            val bitmap = geminiClient.generateImage(prompt)
            if (bitmap != null) {
                val saved = saveImageToGallery(bitmap)
                val message = if (saved) "Görseli galerinize kaydettim" else "Görseli kaydedemedim"
                speak(message) { onComplete() }
            } else {
                speak("Görseli oluşturamadım, lütfen tekrar deneyin") { onComplete() }
            }
        }.start()
    }

    private fun saveImageToGallery(bitmap: Bitmap): Boolean {
        return try {
            val picturesDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            val fileName = "vea_${System.currentTimeMillis()}.png"
            val file = File(picturesDir, fileName)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Metni sesli okur, okuma bitince verilen callback'i çalıştırır. */
    private fun speak(text: String, onDone: () -> Unit) {
        val utteranceId = System.currentTimeMillis().toString()
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                onDone()
            }
            @Deprecated("Deprecated in API")
            override fun onError(utteranceId: String?) {
                onDone()
            }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
