package com.jarvislite.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/**
 * Telefonda yüklü uygulamaları bulur, söylenen sözle eşleştirir ve açar.
 *
 * Mantık basit ve kasıtlı olarak şeffaf:
 * 1) Söylenen komuttan "aç" / "başlat" gibi kelimeleri çıkarıp uygulama adını ayıkla
 * 2) Yüklü uygulamaların görünen isimleriyle bu adı karşılaştır (tam eşleşme -> içerir -> benzerlik)
 * 3) En iyi eşleşeni Intent ile başlat
 */
class AppCommandHandler(private val context: Context) {

    data class InstalledApp(val label: String, val packageName: String)

    // Komuttan "aç" gibi emir kelimelerini temizlemek için kullanılan ifadeler
    private val triggerWords = listOf(
        "aç", "açar mısın", "açabilir misin", "başlat", "çalıştır",
        "open", "launch", "start"
    )

    /** Sistemdeki, kullanıcının görebileceği (launcher'da ikonu olan) tüm uygulamaları listeler. */
    fun getLaunchableApps(): List<InstalledApp> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)

        return resolveInfos.mapNotNull { info ->
            val label = info.loadLabel(pm)?.toString() ?: return@mapNotNull null
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            InstalledApp(label = label, packageName = pkg)
        }.distinctBy { it.packageName }
    }

    /**
     * Ham konuşma metnini alır, içinden uygulama adını çıkarmaya çalışır.
     * Örn: "whatsapp'ı aç" -> "whatsapp"
     */
    private fun extractAppNameFromCommand(rawText: String): String {
        var text = rawText.lowercase().trim()
        for (trigger in triggerWords) {
            text = text.replace(trigger, "")
        }
        // Türkçe iyelik eklerini (basit, yaygın olanları) ayıklamaya çalış
        text = text
            .replace("'ı", "")
            .replace("'i", "")
            .replace("'u", "")
            .replace("'ü", "")
            .replace("ı aç", "")
            .trim()
        return text
    }

    /**
     * Söylenen komuta en uygun uygulamayı bulur.
     * Bulamazsa null döner.
     */
    fun findBestMatch(rawCommand: String): InstalledApp? {
        val query = extractAppNameFromCommand(rawCommand)
        if (query.isBlank()) return null

        val apps = getLaunchableApps()

        // 1) Tam eşleşme (büyük/küçük harf duyarsız)
        apps.firstOrNull { it.label.lowercase() == query }?.let { return it }

        // 2) Uygulama adı, söylenen sözü içeriyor mu veya söylenen söz uygulama adını içeriyor mu
        apps.firstOrNull { it.label.lowercase().contains(query) || query.contains(it.label.lowercase()) }
            ?.let { return it }

        // 3) Kelime bazlı kısmi eşleşme (örn: "yotup" -> "youtube" gibi telaffuz farkları için basit tolerans)
        val queryWords = query.split(" ").filter { it.length > 2 }
        val candidate = apps
            .map { app -> app to similarityScore(app.label.lowercase(), query) }
            .filter { it.second > 0.5 }
            .maxByOrNull { it.second }
            ?.first

        return candidate
    }

    /** Çok basit bir benzerlik skoru: ortak karakter oranına dayalı (Levenshtein yerine hafif bir yöntem). */
    private fun similarityScore(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val shorter = if (a.length < b.length) a else b
        val longer = if (a.length < b.length) b else a
        var matches = 0
        for (ch in shorter) {
            if (longer.contains(ch)) matches++
        }
        return matches.toDouble() / longer.length
    }

    /** Bulunan uygulamayı başlatır. Başarılıysa true döner. */
    fun launchApp(app: InstalledApp): Boolean {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(app.packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return true
    }
}
