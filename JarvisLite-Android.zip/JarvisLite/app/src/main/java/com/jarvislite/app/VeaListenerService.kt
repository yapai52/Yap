package com.jarvislite.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Arka planda çalışıp sürekli mikrofonu dinleyen servis.
 *
 * Nasıl çalışır:
 * - SpeechRecognizer'ı "devamlı dinleme" modunda başlatır
 * - Duyduğu her cümlede "hey vea" / "hey via" gibi varyasyonları arar
 *   (ses tanıma motoru bazen "vea"yı farklı yazabilir, bu yüzden birkaç varyasyon kontrol ediyoruz)
 * - Uyandırma kelimesini bulursa VeaResponder'a haber verir (o da TTS ile cevap verir, komutu dinler)
 * - Dinleme bir cümle bitince otomatik durur, bu yüzden onResults/onError içinde
 *   kendini sürekli yeniden başlatıyoruz ("sonsuz döngü" mantığı)
 *
 * ÖNEMLİ SINIRLAMA: Bu gerçek bir donanım "her zaman açık mikrofon" değil.
 * Telefon arka planda çalışırken pil tüketir ve bazı üreticiler (Xiaomi, Huawei gibi)
 * arka plan servislerini agresifçe kapatabilir — kullanıcı "pil optimizasyonu" ayarından
 * bu uygulamayı muaf tutmalı.
 */
class VeaListenerService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isShuttingDown = false
    private lateinit var responder: VeaResponder

    private val wakeWordVariants = listOf(
        "hey vea", "hey via", "heyvea", "hey wea", "hey bea", "vea"
    )

    companion object {
        private const val TAG = "VeaListenerService"
        private const val CHANNEL_ID = "vea_listener_channel"
        private const val NOTIFICATION_ID = 1
        const val ACTION_STOP = "com.jarvislite.app.STOP_LISTENING"
    }

    override fun onCreate() {
        super.onCreate()
        responder = VeaResponder(this)
        startForeground(NOTIFICATION_ID, buildNotification("Hey Vea için dinliyorum…"))
        startWakeWordListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------- Uyandırma kelimesi dinleme döngüsü ----------

    private fun startWakeWordListening() {
        if (isShuttingDown) return

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = matches?.firstOrNull()?.lowercase().orEmpty()
                Log.d(TAG, "Duyulan: $heard")

                if (wakeWordVariants.any { heard.contains(it) }) {
                    updateNotification("Buyrun, Vea hizmetinizde")
                    responder.respondAndListenForCommand {
                        // Komut işlendikten sonra tekrar uyandırma kelimesi dinlemeye dön
                        updateNotification("Hey Vea için dinliyorum…")
                        restartListening()
                    }
                } else {
                    restartListening()
                }
            }

            override fun onError(error: Int) {
                // ERROR_NO_MATCH / ERROR_SPEECH_TIMEOUT sürekli olacak çünkü sessizlik de bir "hata" sayılır.
                // Bu normal, sadece yeniden başlatıyoruz.
                restartListening()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun restartListening() {
        if (isShuttingDown) return
        // Çok hızlı art arda başlatmak motoru kilitleyebilir, küçük bir gecikme koyuyoruz
        android.os.Handler(mainLooper).postDelayed({ startWakeWordListening() }, 400)
    }

    // ---------- Bildirim (kullanıcı arka planda dinlendiğini her zaman görsün) ----------

    private fun buildNotification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Vea Dinleme Servisi", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, VeaListenerService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis Lite — Vea aktif")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Durdur", stopPendingIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        isShuttingDown = true
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
