package com.jarvislite.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.jarvislite.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var commandHandler: AppCommandHandler
    private lateinit var geminiClient: GeminiClient

    private var isListening = false
    private var isVeaServiceRunning = false

    companion object {
        private const val RECORD_AUDIO_PERMISSION_CODE = 101
        private const val NOTIFICATION_PERMISSION_CODE = 102

        const val ACTION_UNLOCK_REQUEST = "com.jarvislite.app.UNLOCK_REQUEST"
        const val ACTION_LOCK_SCREEN = "com.jarvislite.app.LOCK_SCREEN"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        commandHandler = AppCommandHandler(this)
        geminiClient = GeminiClient(this)

        binding.micButton.setOnClickListener {
            if (isListening) {
                stopListening()
            } else {
                checkPermissionAndStartListening()
            }
        }

        binding.veaToggleButton.setOnClickListener {
            if (isVeaServiceRunning) {
                stopVeaService()
            } else {
                checkPermissionsAndStartVeaService()
            }
        }

        setupSpeechRecognizer()
        handleIncomingAction(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingAction(intent)
    }

    /** VeaResponder, servisten bu Activity'yi belirli eylemler için tetikleyebilir (kilit açma/kapatma). */
    private fun handleIncomingAction(intent: Intent?) {
        when (intent?.action) {
            ACTION_UNLOCK_REQUEST -> showBiometricUnlockPrompt()
            ACTION_LOCK_SCREEN -> lockScreenNow()
        }
    }

    // ---------- "Hey Vea" arka plan servisi ----------

    private fun checkPermissionsAndStartVeaService() {
        val missingPermissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            missingPermissions.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            missingPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this, missingPermissions.toTypedArray(), NOTIFICATION_PERMISSION_CODE
            )
        } else {
            startVeaService()
        }
    }

    private fun startVeaService() {
        val serviceIntent = Intent(this, VeaListenerService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        isVeaServiceRunning = true
        binding.veaToggleButton.text = "Hey Vea'yı durdur"
        binding.statusText.text = "Vea arka planda dinliyor — \"Hey Vea\" diyebilirsiniz"
        Toast.makeText(
            this,
            "İpucu: Pil optimizasyonu ayarlarından bu uygulamayı muaf tutun, yoksa sistem servisi kapatabilir.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun stopVeaService() {
        stopService(Intent(this, VeaListenerService::class.java))
        isVeaServiceRunning = false
        binding.veaToggleButton.text = "Hey Vea'yı başlat"
        binding.statusText.text = getString(R.string.tap_to_speak)
    }

    // ---------- Biyometri ile kilit açma isteği ----------

    private fun showBiometricUnlockPrompt() {
        val biometricManager = BiometricManager.from(this)
        val canAuthenticate = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )

        if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(
                this,
                "Bu cihazda parmak izi/yüz tanıma kurulu değil veya kullanılamıyor.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val biometricPrompt = BiometricPrompt(
            this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    binding.statusText.text = "Kilit açıldı"
                    // NOT: Bu, gerçek sistem kilidini Android güvenlik mimarisi nedeniyle açamaz.
                    // Bu prompt, kullanıcının kimliğini doğrulayıp Vea üzerinden bir "onay" akışı sağlar.
                    // Gerçek ekran kilidi hâlâ kullanıcının kendi PIN/desen/parmak iziyle açılır.
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    binding.statusText.text = "Doğrulama iptal edildi veya başarısız"
                }

                override fun onAuthenticationFailed() {
                    binding.statusText.text = "Doğrulama başarısız, tekrar deneyin"
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Vea Kimlik Doğrulama")
            .setSubtitle("Devam etmek için kimliğinizi doğrulayın")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    // ---------- Ekranı kilitleme ----------

    private fun lockScreenNow() {
        // Ekranı programatik olarak kilitlemek için DevicePolicyManager.lockNow() kullanılır,
        // ancak bu bir "Device Admin" yetkisi ister; kullanıcı bunu vermemişse izin isteriz.
        try {
            val dpm = getSystemService(DevicePolicyManager::class.java)
            val adminComponent = ComponentName(this, VeaDeviceAdminReceiver::class.java)
            if (dpm.isAdminActive(adminComponent)) {
                dpm.lockNow()
                binding.statusText.text = "Ekran kilitlendi"
            } else {
                requestDeviceAdminPermission()
            }
        } catch (e: SecurityException) {
            Toast.makeText(this, "Kilitleme izni verilmedi.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestDeviceAdminPermission() {
        val adminComponent = ComponentName(this, VeaDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Vea'nın \"telefonu kilitle\" komutuyla ekranı kilitleyebilmesi için bu izin gereklidir."
            )
        }
        startActivity(intent)
    }

    // ---------- İzin sonucu ----------

    private fun checkPermissionAndStartListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), RECORD_AUDIO_PERMISSION_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            RECORD_AUDIO_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startListening()
                } else {
                    Toast.makeText(this, getString(R.string.mic_permission_needed), Toast.LENGTH_LONG).show()
                }
            }
            NOTIFICATION_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                    startVeaService()
                } else {
                    Toast.makeText(this, "Mikrofon ve bildirim izni gerekli.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ---------- Tek seferlik ses tanıma (buton modeli) ----------

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            binding.statusText.text = "Bu cihazda ses tanıma desteklenmiyor."
            binding.micButton.isEnabled = false
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                binding.statusText.text = getString(R.string.listening)
                binding.micButton.setBackgroundResource(R.drawable.mic_button_active)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spokenText = matches?.firstOrNull().orEmpty()
                binding.recognizedText.text = "\"$spokenText\""
                handleCommand(spokenText)
                resetMicVisual()
            }

            override fun onError(error: Int) {
                resetMicVisual()
                binding.statusText.text = describeError(error)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!partial.isNullOrBlank()) {
                    binding.recognizedText.text = "\"$partial\""
                }
            }

            override fun onEndOfSpeech() {
                binding.statusText.text = "İşleniyor…"
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer.startListening(intent)
    }

    private fun stopListening() {
        speechRecognizer.stopListening()
        resetMicVisual()
    }

    private fun resetMicVisual() {
        isListening = false
        binding.micButton.setBackgroundResource(R.drawable.mic_button_idle)
        binding.statusText.text = getString(R.string.tap_to_speak)
    }

    private fun describeError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH -> "Anlayamadım, tekrar dener misin?"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Hiçbir şey duymadım."
        SpeechRecognizer.ERROR_NETWORK -> "İnternet bağlantısı sorunu."
        SpeechRecognizer.ERROR_AUDIO -> "Ses kaydı hatası."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> getString(R.string.mic_permission_needed)
        else -> "Bir hata oluştu, tekrar dener misin?"
    }

    private fun handleCommand(spokenText: String) {
        if (spokenText.isBlank()) return

        val match = commandHandler.findBestMatch(spokenText)
        if (match != null) {
            val launched = commandHandler.launchApp(match)
            binding.statusText.text = if (launched) "${match.label} açılıyor" else "${match.label} açılamadı"
        } else {
            binding.statusText.text = "Düşünüyorum…"
            Thread {
                val answer = geminiClient.askQuestion(spokenText)
                runOnUiThread {
                    binding.statusText.text = answer
                }
            }.start()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::speechRecognizer.isInitialized) {
            speechRecognizer.destroy()
        }
    }
}
